package UltraEngine.core.buffers;

import java.awt.Color;

public class Face {

	public int[] indices;
	private Color color;
	
	public Face(int...is) {
		indices = is;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
}
