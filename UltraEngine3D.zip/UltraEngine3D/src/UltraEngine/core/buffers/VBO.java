package UltraEngine.core.buffers;

import java.util.ArrayList;

public class VBO {

	public ArrayList<Face> faces = new ArrayList<Face>();
	
}
