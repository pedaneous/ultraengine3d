package UltraEngine.core.math;

import java.awt.Point;

import UltraEngine.core.renderer.Panel;

public class Vector3 {

	public double x,y,z;
	private Vector3 tex_coords;
	
	public Vector3(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public Vector3 add(Vector3 v) {
		return new Vector3(x+v.x, y+v.y, z+v.z);
	}
	
	public Point convertTo2D(Vector3 position, Vector3 camera) {
		double vf = 500/(500 + position.z + camera.z + z);
		int nx = (int) (vf * (position.x+camera.x+x)) + Panel.width/2;
		int ny = (int) (vf * (-position.y+-camera.y+-y)) + Panel.height/2;
		return new Point(nx, ny);
	}
	
	public double distanceTo(Vector3 p) {
	    return Math.sqrt(Math.pow(x - p.x, 2) + Math.pow(y - p.y, 2) + Math.pow(z - p.z, 2));
	}

	/**
	 * @return the tex_coords
	 */
	public Vector3 getTex_coords() {
		return tex_coords;
	}

	/**
	 * @param tex_coords the tex_coords to set
	 */
	public void setTex_coords(Vector3 tex_coords) {
		this.tex_coords = tex_coords;
	}
	
}
