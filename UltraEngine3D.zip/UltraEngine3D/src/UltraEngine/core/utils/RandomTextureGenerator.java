package UltraEngine.core.utils;

import java.awt.Color;
import java.util.Random;

import UltraEngine.core.buffers.Face;
import UltraEngine.core.buffers.VBO;

public class RandomTextureGenerator {

	private static Random r = new Random();
	
	public static void generateRed(VBO vbo, int min) {
		for(Face f : vbo.faces) {
			int rand = r.nextInt(255-min);
			f.setColor(new Color(rand+min, 0, 0));
		}
	}
	
	public static void generateGreen(VBO vbo, int min) {
		for(Face f : vbo.faces) {
			int rand = r.nextInt(255-min);
			f.setColor(new Color(0, rand+min, 0));
		}
	}
	
	public static void generateBlue(VBO vbo, int min) {
		for(Face f : vbo.faces) {
			int rand = r.nextInt(255-min);
			f.setColor(new Color(0, 0, rand+min));
		}
	}
	
}
