package example.ball;

import java.awt.Color;
import java.awt.Graphics2D;

import UltraEngine.Application;
import UltraEngine.Game;
import UltraEngine.core.math.Vector3;
import UltraEngine.core.renderer.Panel;
import UltraEngine.core.utils.RandomTextureGenerator;
import UltraEngine.core.world.Object3D;

public class Launcher extends Game {
	
	Object3D terrain, ball;
	Vector3 camera = new Vector3(0,0,0);
	
	double sin = 0;
	
	Color sky = new Color(135, 206, 235);
	
	public Launcher() {
		terrain = new Object3D("3.obj", 100);
		terrain.rotate(new Vector3(0,0,180));
		ball = new Object3D("sphere.obj", 100);
		RandomTextureGenerator.generateGreen(terrain.getVBO(), 10);
		RandomTextureGenerator.generateRed(ball.getVBO(), 10);
		new Application(this, "Ultra Engine - Template 1", 1000, 700, false);
	}
	
	public static void main(String[] args) {
		new Launcher();
	}

	@Override
	public void update() {
		sin += 0.05;
		terrain.translate(new Vector3(0,-Math.sin(sin)*5,0));
		ball.translate(new Vector3(0,Math.sin(sin)*5,0));
		ball.rotate(new Vector3(1,0,1));
	}
	
	@Override
	public void draw(Graphics2D g) {
		g.setColor(sky);
		g.fillRect(0, 0, Panel.width, Panel.height);
		terrain.draw(g, camera);
		ball.draw(g, camera);
	}

	@Override
	public void keyPressed(int key, char ch) {
		
	}

	@Override
	public void keyReleased(int key, char ch) {
		
	}

	@Override
	public void mouseClicked(int x, int y) {
	}

	@Override
	public void mouseMoved(int x, int y) {
	}

}
