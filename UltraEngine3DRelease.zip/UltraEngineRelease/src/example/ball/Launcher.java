package example.ball;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import UltraEngine.Application;
import UltraEngine.Game;
import UltraEngine.core.math.Vector3;
import UltraEngine.core.renderer.Panel;
import UltraEngine.core.world.Object3D;

public class Launcher extends Game {
	
	Object3D main;
	Vector3 camera = new Vector3(0,0,0);
	
	double sin = 0;
	
	Color sky = new Color(135, 206, 235);
	
	public Launcher() {
		main = new Object3D("model.obj", 500);
		new Application(this, "Ultra Engine - Template 1", 1000, 700, false);
	}
	
	public static void main(String[] args) {
		new Launcher();
	}

	@Override
	public void update() {
		main.rotate(new Vector3(1,0,0));
	}
	
	@Override
	public void draw(Graphics2D g) {
		g.setColor(sky);
		g.fillRect(0, 0, Panel.width, Panel.height);
		main.draw(g, camera);
	}

	@Override
	public void keyPressed(int key, char ch) {
		
	}

	@Override
	public void keyReleased(int key, char ch) {
		
	}

	@Override
	public void mouseClicked(int x, int y) {
	}

	@Override
	public void mouseMoved(int x, int y) {
	}

}
