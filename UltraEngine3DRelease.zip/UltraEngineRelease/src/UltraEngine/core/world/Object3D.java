package UltraEngine.core.world;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;

import UltraEngine.core.buffers.Face;
import UltraEngine.core.buffers.VAO;
import UltraEngine.core.buffers.VBO;
import UltraEngine.core.math.Vector3;
import UltraEngine.core.utils.MTLParser;

public class Object3D {

	private VAO vao;
	private VBO vbo;
	
	public Vector3 position = new Vector3(0,0,0);
	
	public VAO getVAO() {
		return vao;
	}

	public void setVAO(VAO vao) {
		this.vao = vao;
	}

	public VBO getVBO() {
		return vbo;
	}

	public void setVBO(VBO vbo) {
		this.vbo = vbo;
	}

	public Vector3 getPosition() {
		return position;
	}

	public void setPosition(Vector3 position) {
		this.position = position;
	}

	public Object3D(String file, double scale) {
		vao = new VAO();
		vbo = new VBO();
		loadOBJ(file, scale);
	}
	
	private void loadOBJ(String file, double scale) {
		try {
			MTLParser parser = null;
			BufferedReader br = new BufferedReader(new FileReader(file));
			String current = "";
			String currentMaterial = "";
			while((current = br.readLine()) != null) {
				String[] tokens = current.split(" ");
				if(tokens[0].equals("mtllib")) {
					parser = new MTLParser(tokens[1]);
				}
				if(tokens[0].equals("v")) {
					double x = Double.valueOf(tokens[1])*scale;
					double y = Double.valueOf(tokens[2])*scale;
					double z = Double.valueOf(tokens[3])*scale;
					vao.mesh.add(new Vector3(x,y,z));
				}
				if(tokens[0].equals("usemtl")) {
					currentMaterial = tokens[1];
					System.out.println(currentMaterial + " - " + parser.getColorFromMaterial(currentMaterial));
				}
				if(tokens[0].equals("f")) {
					ArrayList<Integer> temp = new ArrayList<Integer>();
					for(int i = 1; i < tokens.length; i++) {
						temp.add(Integer.valueOf(tokens[i].split("/")[0]));
					}
					int[] tempA = new int[temp.size()];
					for(int i = 0; i < temp.size(); i++) tempA[i] = temp.get(i);
					Face f = new Face(tempA);
					f.setColor(parser.getColorFromMaterial(currentMaterial));
					vbo.faces.add(f);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setColor(Color c) {
		for(Face f : vbo.faces) {
			f.setColor(c);
		}
	}
	
	public void translate(Vector3 translation) {
		position = position.add(translation);
	}
	
	public void rotate(Vector3 rotation) {
		for(Vector3 v : vao.mesh) {
			double sin = Math.sin(rotation.x*Math.PI/180);
            double cos = Math.cos(rotation.x*Math.PI/180);
            
            double temp = (v.x * cos) - (v.z * sin);
            v.z = (v.x * sin) + (v.z * cos);
            v.x = temp;
            
            sin = Math.sin(rotation.y*Math.PI/180);
            cos = Math.cos(rotation.y*Math.PI/180);
            
            temp = (v.z * cos) - (v.y * sin);
            v.y = (v.z * sin) + (v.y * cos);
            v.z = temp;
            
            sin = Math.sin(rotation.z * Math.PI/180);
            cos = Math.cos(rotation.z * Math.PI/180);
            
            temp = (v.y * cos) - (v.x * sin);
            v.x = (v.y * sin) + (v.x * cos);
            v.y = temp;
		}
	}
	
	public void draw(Graphics2D g, Vector3 camera) {
		vbo.faces.sort(new Comparator<Face>() {
			@Override
			public int compare(Face arg0, Face arg1) {
				Vector3 v1 = vao.mesh.get(arg0.indices[0] - 1);
				Vector3 v2 = vao.mesh.get(arg1.indices[0] - 1);
				if (v1.z > v2.z)
					return -1;
				if (v1.z < v2.z)
					return 1;
				return 0;
			}
		});
		for(Face f : vbo.faces) {
			Polygon p = new Polygon();
			for(int j = 0; j < f.indices.length; j++) {
				Vector3 v = vao.mesh.get(f.indices[j]-1);
				if(v.z + camera.z + position.z > -500) {
					Point point2D = v.convertTo2D(position, camera);
					p.addPoint(point2D.x, point2D.y);
				}
			}
			g.setColor(f.getColor());
			g.fill(p);
		}
	}
	
	public void update() {
		
	}
	
}
