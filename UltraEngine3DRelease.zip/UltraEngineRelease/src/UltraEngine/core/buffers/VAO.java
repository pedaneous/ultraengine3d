package UltraEngine.core.buffers;

import java.util.ArrayList;

import UltraEngine.core.math.Vector3;

public class VAO {

	public ArrayList<Vector3> mesh = new ArrayList<Vector3>();
	
}
