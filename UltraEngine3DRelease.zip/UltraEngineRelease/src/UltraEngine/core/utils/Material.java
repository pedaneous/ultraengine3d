package UltraEngine.core.utils;

import java.awt.Color;

public class Material {

	public String name;
	public Color color;
	
	public Material(String name) {
		this.name = name;
	}
	
}
