package UltraEngine.core.utils;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import UltraEngine.core.buffers.VBO;

public class ImageTextureGenerator {
	
	public void applyTexturedImage(VBO vbo, String file) {
		try {
			BufferedImage img = ImageIO.read(new File(file));
			for(int i = 0; i < vbo.faces.size(); i++) {
					vbo.faces.get(i).setColor(new Color(img.getRGB(i%img.getWidth(), i%img.getHeight())));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
