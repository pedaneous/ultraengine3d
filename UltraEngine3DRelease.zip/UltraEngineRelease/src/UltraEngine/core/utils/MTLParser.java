package UltraEngine.core.utils;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;


public class MTLParser {

	BufferedReader br;
	ArrayList<Material> material = new ArrayList<Material>();
	
	public MTLParser(String file) {
		try {
			br = new BufferedReader(new FileReader(file));
			String current = "";
			while((current = br.readLine()) != null) {
				String[] tokens = current.split(" ");
				if(tokens[0].equals("newmtl")) {
					material.add(new Material(tokens[1]));
				}
				if(tokens[0].equals("Kd")) {
					double r = Double.valueOf(tokens[1]);
					double g = Double.valueOf(tokens[2]);
					double b = Double.valueOf(tokens[3]);
					r*=255;
					g*=255;
					b*=255;
					int rInt = (int) r;
					int gInt = (int) g;
					int bInt = (int) b;
					material.get(material.size()-1).color = new Color(rInt, gInt, bInt);
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Color getColorFromMaterial(String name) {
		for(Material m : material) {
			if(m.name.equals(name)) {
				return m.color;
			}
		}
		return null;
	}
	
}
